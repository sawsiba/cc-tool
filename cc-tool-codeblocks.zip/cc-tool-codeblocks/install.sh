#!/bin/sh

mkdir -p /usr/local/share/man/man1 && cp ./man/cc-tool.1 "$_"
gzip /usr/local/share/man/man1/cc-tool.1

mkdir -p /usr/local/bin && cp ./cc-tool/bin/Debug/cc-tool "$_"

mkdir -p /etc/udev/rules.d && cp ./udev/90-cc-debugger.rules  "$_"

mkdir -p /usr/local/share/doc/cc-tool && cp ./docs/chip_table.odt  "$_"
